package com.example.provessentilo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
	
	private URL url;
	private HttpURLConnection conn;
	private BufferedReader rd = null;
	private StringBuilder sb;
	private  JSONArray ja;
	private JSONObject jo;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       
        final Button boto = (Button) findViewById(R.id.button1);
        final TextView text = (TextView) findViewById(R.id.textView4);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();        
        StrictMode.setThreadPolicy(policy);
        
        text.setVisibility(View.INVISIBLE);
        
        boto.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				text.setVisibility(View.VISIBLE);
			    boto.setVisibility(View.INVISIBLE);
				StringBuilder urlBuilder = new StringBuilder("http://icity-gw.icityproject.com:8080/developer/api/observations/last");
		        urlBuilder.append("?");
		        try {
					urlBuilder.append(URLEncoder.encode("id","UTF-8") + "=" + URLEncoder.encode("980", "UTF-8") + "&");
				} catch (UnsupportedEncodingException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
		        try {
					urlBuilder.append(URLEncoder.encode("property","UTF-8") + "=" + URLEncoder.encode("urn:temperature", "UTF-8") + "&");
				} catch (UnsupportedEncodingException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
		        try {
					urlBuilder.append(URLEncoder.encode("apikey","UTF-8") + "=" + URLEncoder.encode("l7xxece37e28d4314ff4afc2e8691d7e874d", "UTF-8"));
				} catch (UnsupportedEncodingException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
		      
				try {
					url = new URL(urlBuilder.toString());
				} catch (MalformedURLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				try {
					conn = (HttpURLConnection) url.openConnection();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			    try {
					conn.setRequestMethod("GET");
				} catch (ProtocolException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			    try {
					System.out.println("Response code: " + conn.getResponseCode());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		        try {
					if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
					    rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
					} else {
					    rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		        sb = new StringBuilder();
		        String line;
		        try {
					while ((line = rd.readLine()) != null) {
					    sb.append(line);
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		        try {
					rd.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		        conn.disconnect();
		        try {
					ja = new JSONArray(sb.toString());
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		        try {
					jo = ja.getJSONObject(0);
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		        try {
					text.setText("Observaci�n: " + jo.getString("value")+"�C");
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}	
        });
    }
}

package com.example.fontsaigua;

import android.app.Activity;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends Activity {

	private GoogleMap map;
	private String[] latitud, longitud;
	private static final LatLng BARCELONA = new LatLng(41.396623, 2.163391);
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		//StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
	    //StrictMode.setThreadPolicy(policy); 
		
		map = ((MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMap();
	    map.moveCamera(CameraUpdateFactory.newLatLngZoom(BARCELONA, 11));
	    
	    CreateArrayFuentes();
	}
	
    private void CreateArrayFuentes(){
    	latitud = getResources().getStringArray(R.array.LatitudesFuentesAgua);
        longitud = getResources().getStringArray(R.array.LongitudesFuentesAgua);
        Marker marker;
                for(int i=0; i<latitud.length;i++){
                	marker = map.addMarker(new MarkerOptions()
                            .position(new LatLng(Double.parseDouble(latitud[i]),Double.parseDouble(longitud[i])))
                            .icon(BitmapDescriptorFactory
                            .defaultMarker(BitmapDescriptorFactory.HUE_RED)));
                }
    }
}

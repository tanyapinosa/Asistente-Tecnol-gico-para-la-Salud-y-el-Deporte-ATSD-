package com.example.dibuixarutes;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity implements OnMapLongClickListener {

	private GoogleMap map;
	private static final LatLng BARCELONA = new LatLng(41.396623, 2.163391);
	private List<LatLng> markers = new ArrayList<LatLng>();
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        final Button PintaRuta = (Button) findViewById(R.id.button1);
        
        map = ((MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMap();
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(BARCELONA, 11));      
        map.setOnMapLongClickListener(this);
        
        PintaRuta.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            		for (int i=0; i<markers.size()-1; i++){
            			 LatLng src = markers.get(i);
            			 LatLng dest = markers.get(i + 1); 
            			 Polyline line = map.addPolyline(
            					    new PolylineOptions().add(
            					    new LatLng(src.latitude, src.longitude),
            					    new LatLng(dest.latitude,dest.longitude)
            					    ).width(3).color(Color.BLUE).geodesic(true)
            					  );
            		}
            }
        });
    }

	@Override
	public void onMapLongClick(LatLng arg0) {
		// TODO Auto-generated method stub
		map.addMarker(new MarkerOptions().position(arg0).title(arg0.toString()));
		markers.add(arg0);
	}
}

package com.example.sensorsperproximitat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMapLongClickListener;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends Activity implements OnMapLongClickListener {

	private GoogleMap map;
	private LatLng marker;
	private HttpURLConnection conn;
	private BufferedReader rd;
	private JSONObject jo;
	private JSONObject jb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        final Button boto = (Button)findViewById(R.id.button1);
        
        map = ((MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMap();
	    map.setOnMapLongClickListener(this);
	    
	    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy); 
        
	    Toast.makeText(getApplicationContext(), "Seleccione su ubicaci�n", Toast.LENGTH_LONG).show();
	  
	    boto.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	boto.setVisibility(View.INVISIBLE);
            	 StringBuilder urlBuilder = new StringBuilder("http://icity-gw.icityproject.com:8080/developer/api/radius/");
                 urlBuilder.append("?");
                 try {
					urlBuilder.append(URLEncoder.encode("latitude","UTF-8") + "=" + URLEncoder.encode(String.valueOf(marker.latitude), "UTF-8") + "&");
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                 try {
					urlBuilder.append(URLEncoder.encode("longitude","UTF-8") + "=" + URLEncoder.encode(String.valueOf(marker.longitude), "UTF-8") + "&");
				} catch (UnsupportedEncodingException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
                 try {
					urlBuilder.append(URLEncoder.encode("distance","UTF-8") + "=" + URLEncoder.encode("50", "UTF-8") + "&");
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                 try {
					urlBuilder.append(URLEncoder.encode("apikey","UTF-8") + "=" + URLEncoder.encode("l7xxece37e28d4314ff4afc2e8691d7e874d", "UTF-8"));
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                 URL url=null;
				try {
					url = new URL(urlBuilder.toString());
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                 
				try {
					conn = (HttpURLConnection) url.openConnection();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                 try {
					conn.setRequestMethod("GET");
				} catch (ProtocolException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                 try {
					System.out.println("Response code: " + conn.getResponseCode());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
          try {
			if(conn.getResponseCode()>=200 && conn.getResponseCode() <= 300){
			         try {
						if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
						     rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
						 } else {
						     rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
						 }
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			         StringBuilder sb = new StringBuilder();
			         String line;
			         try {
						while ((line = rd.readLine()) != null) {
						     sb.append(line);
						 }
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			         try {
						rd.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			         conn.disconnect();
			         System.out.println(sb.toString());
			         try {
			 			jo = new JSONObject(sb.toString());
			 		} catch (JSONException e) {
			 			// TODO Auto-generated catch block
			 			e.printStackTrace();
			 		}
			         try {
			        	Iterator<String> keys = jo.keys();
			        	while( keys.hasNext() ){
			        		String key = keys.next();
			        		try {
								jb=jo.getJSONObject(key);
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
			        		try {
								Marker marker = map.addMarker(new MarkerOptions()
								.position(new LatLng(Double.parseDouble(jb.getString("latitude")),Double.parseDouble(jb.getString("longitude"))))
								.title(jb.getString("deviceID"))
								.icon(BitmapDescriptorFactory
								.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
			        	}
			        	}
			    catch (NumberFormatException e) {
			 			// TODO Auto-generated catch block
			 			e.printStackTrace();
			 		}
			         try {
			 			System.out.println(jo.getString("latitude"));
			 		} catch (JSONException e) {
			 			// TODO Auto-generated catch block
			 			e.printStackTrace();
			 		}                
			    }
			else  Toast.makeText(getApplicationContext(), "No hay sensores visibles en un radio de 50km desde esta localizaci�n", Toast.LENGTH_LONG).show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	     
            }
        });       
    }

	@Override
	public void onMapLongClick(LatLng arg0) {
		// TODO Auto-generated method stub
		map.addMarker(new MarkerOptions().position(arg0).title(arg0.toString())
				.icon(BitmapDescriptorFactory
                .defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));
		marker=arg0;
	}
}

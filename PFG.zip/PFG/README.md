# Asistente-Tecnol-gico-para-la-Salud-y-el-Deporte-ATSD-
Demo-aplicaciones y versión-modelo de aplicación final para mi Proyecto de Fin de Grado en Ingeniería de Sistemas Audiovisuales, por la Universidad Politécnica de Catalunya.
